import UIKit
import Foundation

protocol Flyer {
  func fly()
  func flyTo(Location: String)
}
protocol SpaceTraveler {
  func travelTo(location: String)
}

protocol Named {
  var name: String { get }
}

protocol Human: Named {
  var countryOfOrigin: String? { get }
  init(name: String, countryOfOrigin: String?)
}

protocol Alien: Named {
  var species: String { get }
}
protocol Bird: Named {
  var birdType:String{get}
}

protocol Insect: Named{
    var insectType:String{get}
}
protocol CanEat {
    func eat()
}

protocol Quotable {
  var catchPhrases: [String] { get }
  func randomQuote() -> String
}

///   Provide Default Implementations

extension Flyer {
  func fly() {
    print("I can fly")
  }
    func flyTo(Location:String){
        print("lets Fly to \(Location)")
    }
}

extension SpaceTraveler {
  func travelTo(location: String) {
    print("Let's go to \(location)!")
  }
}

extension Named {
  func sayHello() {
    print("Hello, I am \(name)")
  }
}
extension CanEat {
  func eat() {
    print("I can eat")
  }
}
extension Quotable {
  func randomQuote() -> String {
    return catchPhrases[Int(arc4random_uniform(UInt32(catchPhrases.count)))]
  }
}

extension Human {
  init(name: String, countryOfOrigin: String? = nil) {
    self.init(name: name, countryOfOrigin: countryOfOrigin)
  }
}

extension Insect{
    init(name: String, insectType:String) {
        self.init(name: name, insectType: insectType)
    }
}

// For types that are both Named and Quotable
extension Named where Self: Quotable {
  func sayHello() {
    print("Hello, I am \(name). \(randomQuote())")
  }
}

// For types that are both Human and Alien
extension Human where Self: Alien {
  func sayHello() {
    print("I'm \(name) and I'm half Human, half \(species)")
  }
}

//: ## Define the Characters

struct Bee: Insect, Flyer, Quotable {
  var insectType: String = "Flyer"
  var currentLocation = "Honey Comb"
  let name = "honeyBee"
  let catchPhrases: [String]
}

struct Icarus: Human,Flyer,CanEat {
  var currentLocation = "Athens"
  let name = "I'm the Icarus, the son of the master craftsman Daedalus, the creator of the Labyrinth"
  let countryOfOrigin: String? = "Greece"
}

struct Superman: Alien, Flyer, SpaceTraveler {
  let name = "Clark Kent"
  let species = "Kryptonian"
}

struct IronMan: Human, Flyer {
  let name = "Tony Stark"
  let countryOfOrigin: String? = "USA"
  func fly() {
    print("J.A.R.V.I.S. Fly!")
  }
}

struct Astraunaut: Named, SpaceTraveler {
  let name: String
}

struct MilleniumFalconPilot: Named, SpaceTraveler {
  let name: String
}

struct Spock: Human, Alien, SpaceTraveler {
  let name = "Spock"
  let countryOfOrigin: String? = nil
  let species = "Vulcan"
}

///    Create People!

let bee = Bee(catchPhrases: ["buzzz!", "wiiizzzzz!" , "ZZzzzzZZZZZ!"])
bee.sayHello()
bee.flyTo(Location: "Flower Garden")

let clark = Superman()
clark.fly()
clark.travelTo(location: "Earth")

let tony = IronMan()
tony.fly()

let spock = Spock()
spock.name
spock.species
spock.sayHello()
