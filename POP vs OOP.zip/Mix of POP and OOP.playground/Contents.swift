import UIKit

protocol Flyer {
    //since this is an example we use String instead of real location
    var currentLocation:String{get set}
    mutating func flyTo(Location:String )
    func fly()
}
/// Default Implemantation of flyer
extension Flyer {
    func fly() {
        print("I can fly")
    }
    mutating func flyTo(Location: String) {
        currentLocation = Location
    }
}

protocol CanEat{
    func eat()
}

/// Default Implemantation of CanEat
extension CanEat {
    func eat(){
        print("I can eat.")
    }
}


protocol SpaceTraveler {
  func travelTo(location: String)
}

/// Default Implemantation of SpaceTraveler
extension SpaceTraveler {
  func travelTo(location: String) {
    print("Let's go to \(location)!")
  }
}

/// our object and models of creatures
class Creature {
    var name: String?
    init(name: String) {
        self.name = name
    }
}

class Human: Creature {
    var countryOfOrigin: String?
    init(name: String, countryOfOrigin: String? = nil) {
        self.countryOfOrigin = countryOfOrigin
        super.init(name: name)
    }
}
class Alien: Creature {
  let species: String
  init(name: String, species: String) {
    self.species = species
    super.init(name: name)
  }
}

class Insect: Creature {
    let insectType: String?
    init(name: String, insectType: String) {
        self.insectType = insectType
        super.init(name: name)
    }
}
class Bird: Creature {
    let birdType:String?
    init(name: String, birdType: String){
        self.birdType = birdType
        super.init(name:name)
    }
}

/// adding ability/Traits to a classs  using extensions

extension Superman: SpaceTraveler {}


/// defining creatures make some population for your  World as long as you're god you are able to create anything

class Icarus: Human, Flyer, CanEat{
    
    var currentLocation:String = "Greece"
    init() {
        super.init(name: "I'm the Icarus, the son of the master craftsman Daedalus, the creator of the Labyrinth", countryOfOrigin: "Greece")
    }
}

class Superman: Alien , Flyer {
    var currentLocation: String = "Earth"
  init() {
    super.init(name: "Clark Kent", species: "Kryptonian")
  }
}

class Bee: Insect, Flyer {
    var currentLocation: String = "HoneyComb"
    
    init() {
        super.init(name: "HoneyBee ", insectType: "Fly")
    }
}
class Spider:Insect,CanEat{
    var spiderType:String? = "Dangerous"
    init(){
        super.init(name: "Black Widow", insectType: "Spider")
    }
}

class IronMan: Human, Flyer ,CanEat {
    var currentLocation: String = "California"
    
    init() {
        super.init(name: "Tony Stark", countryOfOrigin: "USA")
    }
}
class Tree:Creature {
    var treeType:String? = "Balsam Fir"
    init(){
        super.init(name: "Christmass Tree")
    }
}


/// let see if this mixin and traits are  working fine

let theIcarus = Icarus()
theIcarus.fly() // prints "I can fly"
theIcarus.name// returns "Tony Stark"
theIcarus.eat()

let blackWidow = Spider()
blackWidow.eat() // prints "I believe I can flyyyyy ♬"
blackWidow.name  // returns "Kryptonian"
blackWidow.eat()

let christmassTree = Tree()
christmassTree.name

let tony = IronMan()
tony.name
tony.fly()
tony.eat()


var honeyBee = Bee()
honeyBee.currentLocation // Apr 22, 2011, 5:02 PM
honeyBee.flyTo(Location: "Flower Garden")
honeyBee.fly() // "Gallifreyan"
honeyBee.name

let clark = Superman()
clark.fly() // prints "I believe I can flyyyyy ♬"
clark.species  // returns "Kryptonian"



clark.travelTo(location: "Trenzalore") // prints "Let's go to Trenzalore!"



/// bring more people to the world

class Astraunaut: Human, SpaceTraveler {}
let neilArmstrong = Astraunaut(name: "Neil Armstrong", countryOfOrigin: "USA")
let laika = Astraunaut(name: "Laïka", countryOfOrigin: "Russia")
// Wait, Laïka is a Dog, right?

class MilleniumFalconPilot: Human, SpaceTraveler {}
let hanSolo = MilleniumFalconPilot(name: "Han Solo")
let chewbacca = MilleniumFalconPilot(name: "Chewie")
// Wait, isn't MilleniumFalconPilot defined as "Human"?!

class Spock: Alien, SpaceTraveler {
  init() {
    super.init(name: "Spock", species: "Vulcan")
    // Woops not 100% right
  }
}


/// better soloution for creating your world USE MORE PROTOCOLS  Fella use POP instead of OOP

